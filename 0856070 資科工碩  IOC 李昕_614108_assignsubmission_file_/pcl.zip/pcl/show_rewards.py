#!/usr/bin/env python
# coding: utf-8

# In[17]:


import string
get_ipython().run_line_magic('matplotlib', 'inline')
import numpy as np
import matplotlib.pyplot as plt
### --- Figure config
LEGEND_SIZE = 15


# In[152]:


### read files, pcl

## learning rate = 0.005, 0.01, 0.05, 0.1
# 0.005
pcl_avg_reward_lr_dot005 = []
f = open('./pcl_rl_lr0.005/rewards.txt')
for line in f : 
    line_split = line.split(', ')
    pcl_avg_reward_lr_dot005.append(float(line_split[1].split(' : ')[1]))
f.close()

# 0.01
pcl_avg_reward_lr_dot01 = []
f = open('./pcl_rl_lr0.01/rewards.txt')
for line in f : 
    line_split = line.split(', ')
    pcl_avg_reward_lr_dot01.append(float(line_split[1].split(' : ')[1]))
f.close()

# 0.05
pcl_avg_reward_lr_dot05 = []
f = open('./pcl_rl_lr0.05/rewards.txt')
for line in f : 
    line_split = line.split(', ')
    pcl_avg_reward_lr_dot05.append(float(line_split[1].split(' : ')[1]))
f.close()

# 0.1
pcl_avg_reward_lr_dot1 = []
f = open('./pcl_rl_lr0.1/rewards.txt')
for line in f : 
    line_split = line.split(', ')
    pcl_avg_reward_lr_dot1.append(float(line_split[1].split(' : ')[1]))
f.close()


## tau = 0.01, 0.05, 0.1, 0.5
# 0.01
pcl_avg_reward_tau_dot01 = []
f = open('./pcl_rl_tau0.01/rewards.txt')
for line in f : 
    line_split = line.split(', ')
    pcl_avg_reward_tau_dot01.append(float(line_split[1].split(' : ')[1]))
f.close()

# 0.05
pcl_avg_reward_tau_dot05 = []
f = open('./pcl_rl_tau0.05/rewards.txt')
for line in f : 
    line_split = line.split(', ')
    pcl_avg_reward_tau_dot05.append(float(line_split[1].split(' : ')[1]))
f.close()

# 0.1
pcl_avg_reward_tau_dot1 = []
f = open('./pcl_rl_tau0.1/rewards.txt')
for line in f : 
    line_split = line.split(', ')
    pcl_avg_reward_tau_dot1.append(float(line_split[1].split(' : ')[1]))
f.close()

# 0.5
pcl_avg_reward_tau_dot5 = []
f = open('./pcl_rl_tau0.5/rewards.txt')
for line in f : 
    line_split = line.split(', ')
    pcl_avg_reward_tau_dot5.append(float(line_split[1].split(' : ')[1]))
f.close()


## critic weight = 0.1, 0.5, 1.0
# 0.1
pcl_avg_reward_critic_weight_dot1 = []
f = open('./pcl_rl_critic_weight0.1/rewards.txt')
for line in f : 
    line_split = line.split(', ')
    pcl_avg_reward_critic_weight_dot1.append(float(line_split[1].split(' : ')[1]))
f.close()

# 0.5
pcl_avg_reward_critic_weight_dot5 = []
f = open('./pcl_rl_critic_weight0.5/rewards.txt')
for line in f : 
    line_split = line.split(', ')
    pcl_avg_reward_critic_weight_dot5.append(float(line_split[1].split(' : ')[1]))
f.close()

# 1.0
pcl_avg_reward_critic_weight_dot10 = []
f = open('./pcl_rl_critic_weight1.0/rewards.txt')
for line in f : 
    line_split = line.split(', ')
    pcl_avg_reward_critic_weight_dot10.append(float(line_split[1].split(' : ')[1]))
f.close()

# best 3
pcl_avg_reward_best3 = []
f = open('./pcl_rl_best3/rewards.txt')
for line in f : 
    line_split = line.split(', ')
    pcl_avg_reward_best3.append(float(line_split[1].split(' : ')[1]))
f.close()

# best3, lr = 0.005
pcl_avg_reward_best3_1 = []
f = open('./pcl_rl_best3/rewards_1.txt')
for line in f : 
    line_split = line.split(', ')
    pcl_avg_reward_best3_1.append(float(line_split[1].split(' : ')[1]))
f.close()


# In[150]:


### read files, a3c

## learning rate = 0.005, 0.01, 0.05, 0.1
# 0.005
a3c_avg_reward_lr_dot005 = []
f = open('./a3c/a3c_lr0.005/rewards.txt')
for line in f : 
    line_split = line.split(', ')
    a3c_avg_reward_lr_dot005.append(float(line_split[1].split(' : ')[1]))
f.close()

# 0.01
a3c_avg_reward_lr_dot01 = []
f = open('./a3c/a3c_lr0.01/rewards.txt')
for line in f : 
    line_split = line.split(', ')
    a3c_avg_reward_lr_dot01.append(float(line_split[1].split(' : ')[1]))
f.close()

# 0.05
a3c_avg_reward_lr_dot05 = []
f = open('./a3c/a3c_lr0.05/rewards.txt')
for line in f : 
    line_split = line.split(', ')
    a3c_avg_reward_lr_dot05.append(float(line_split[1].split(' : ')[1]))
f.close()

# 0.1
a3c_avg_reward_lr_dot1 = []
f = open('./a3c/a3c_lr0.1/rewards.txt')
for line in f : 
    line_split = line.split(', ')
    a3c_avg_reward_lr_dot1.append(float(line_split[1].split(' : ')[1]))
f.close()


## tau = 0.01, 0.05, 0.1, 0.5
# 0.01
a3c_avg_reward_tau_dot01 = []
f = open('./a3c/a3c_tau0.01/rewards.txt')
for line in f : 
    line_split = line.split(', ')
    a3c_avg_reward_tau_dot01.append(float(line_split[1].split(' : ')[1]))
f.close()

# 0.05
a3c_avg_reward_tau_dot05 = []
f = open('./a3c/a3c_tau0.05/rewards.txt')
for line in f : 
    line_split = line.split(', ')
    a3c_avg_reward_tau_dot05.append(float(line_split[1].split(' : ')[1]))
f.close()

# 0.1
a3c_avg_reward_tau_dot1 = []
f = open('./a3c/a3c_tau0.1/rewards.txt')
for line in f : 
    line_split = line.split(', ')
    a3c_avg_reward_tau_dot1.append(float(line_split[1].split(' : ')[1]))
f.close()

# 0.5
a3c_avg_reward_tau_dot5 = []
f = open('./a3c/a3c_tau0.5/rewards.txt')
for line in f : 
    line_split = line.split(', ')
    a3c_avg_reward_tau_dot5.append(float(line_split[1].split(' : ')[1]))
f.close()


## critic weight = 0.1, 0.5, 1.0
# 0.1
a3c_avg_reward_critic_weight_dot1 = []
f = open('./a3c/a3c_critic_weight0.1/rewards.txt')
for line in f : 
    line_split = line.split(', ')
    a3c_avg_reward_critic_weight_dot1.append(float(line_split[1].split(' : ')[1]))
f.close()

# 0.5
a3c_avg_reward_critic_weight_dot5 = []
f = open('./a3c/a3c_critic_weight0.5/rewards.txt')
for line in f : 
    line_split = line.split(', ')
    a3c_avg_reward_critic_weight_dot5.append(float(line_split[1].split(' : ')[1]))
f.close()

# 1.0
a3c_avg_reward_critic_weight_dot10 = []
f = open('./a3c/a3c_critic_weight1.0/rewards.txt')
for line in f : 
    line_split = line.split(', ')
    a3c_avg_reward_critic_weight_dot10.append(float(line_split[1].split(' : ')[1]))
f.close()

# best 3
a3c_avg_reward_best3 = []
f = open('./a3c/a3c_best3/rewards.txt')
for line in f : 
    line_split = line.split(', ')
    a3c_avg_reward_best3.append(float(line_split[1].split(' : ')[1]))
f.close()

a3c_avg_reward_best3_1 = []
f = open('./a3c/a3c_best3/rewards_1.txt')
for line in f : 
    line_split = line.split(', ')
    a3c_avg_reward_best3_1.append(float(line_split[1].split(' : ')[1]))
f.close()


# In[146]:


### try subplot
LEGEND_SIZE_SUB = 7

plt.figure(figsize=(15, 10))

plt.subplot(2, 3, 1)
plt.plot(pcl_avg_reward_lr_dot005, label='lr = 0.005')
plt.plot(pcl_avg_reward_lr_dot01, label='lr = 0.01')
plt.plot(pcl_avg_reward_lr_dot05, label='lr = 0.05')
plt.plot(pcl_avg_reward_lr_dot1, label='lr = 0.1')
plt.legend(loc='upper left', prop={'size': LEGEND_SIZE_SUB})
plt.grid(True)
plt.title('pcl, lr')
plt.xlabel('steps (25)')
plt.ylabel('average rewards')

plt.subplot(2, 3, 2)
plt.plot(pcl_avg_reward_tau_dot01, label='tau = 0.01')
plt.plot(pcl_avg_reward_tau_dot05, label='tau = 0.05')
plt.plot(pcl_avg_reward_tau_dot1, label='tau = 0.1')
plt.plot(pcl_avg_reward_tau_dot5, label='tau = 0.5')
plt.legend(loc='upper left', prop={'size': LEGEND_SIZE_SUB})
plt.grid(True)
plt.title('pcl, tau')
plt.xlabel('steps (25)')

plt.subplot(2, 3, 3)
plt.plot(pcl_avg_reward_critic_weight_dot1, label='critic weight = 0.1')
plt.plot(pcl_avg_reward_critic_weight_dot5, label='critic weight = 0.5')
plt.plot(pcl_avg_reward_critic_weight_dot10, label='critic weight = 1.0')
plt.legend(loc='upper left', prop={'size': LEGEND_SIZE_SUB})
plt.grid(True)
plt.title('pcl, critic weight')
plt.xlabel('steps (25)')

plt.subplot(2, 3, 4)
plt.plot(a3c_avg_reward_lr_dot005, label='lr = 0.005')
plt.plot(a3c_avg_reward_lr_dot01, label='lr = 0.01')
plt.plot(a3c_avg_reward_lr_dot05, label='lr = 0.05')
plt.plot(a3c_avg_reward_lr_dot1, label='lr = 0.1')
plt.legend(loc='upper left', prop={'size': LEGEND_SIZE_SUB})
plt.grid(True)
plt.title('a3c, lr')
plt.xlabel('steps (25)')
plt.ylabel('average rewards')

plt.subplot(2, 3, 5)
plt.plot(a3c_avg_reward_tau_dot01, label='tau = 0.01')
plt.plot(a3c_avg_reward_tau_dot05, label='tau = 0.05')
plt.plot(a3c_avg_reward_tau_dot1, label='tau = 0.1')
plt.plot(a3c_avg_reward_tau_dot5, label='tau = 0.5')
plt.legend(loc='upper left', prop={'size': LEGEND_SIZE_SUB})
plt.grid(True)
plt.title('a3c, tau')
plt.xlabel('steps (25)')

plt.subplot(2, 3, 6)
plt.plot(a3c_avg_reward_critic_weight_dot1, label='critic weight = 0.1')
plt.plot(a3c_avg_reward_critic_weight_dot5, label='critic weight = 0.5')
plt.plot(a3c_avg_reward_critic_weight_dot10, label='critic weight = 1.0')
plt.legend(loc='upper left', prop={'size': LEGEND_SIZE_SUB})
plt.grid(True)
plt.title('a3c, critic weight')
plt.xlabel('steps (25)')

plt.show()


# In[107]:


### plot
## pcl, learning rate
plt.figure(figsize=(12, 8))
plt.plot(pcl_avg_reward_lr_dot005, label='lr = 0.005')
plt.plot(pcl_avg_reward_lr_dot01, label='lr = 0.01')
plt.plot(pcl_avg_reward_lr_dot05, label='lr = 0.05')
plt.plot(pcl_avg_reward_lr_dot1, label='lr = 0.1')
plt.legend(loc='upper left', prop={'size': LEGEND_SIZE})
plt.grid(True)
plt.title('pcl reward, learning rate = 0.005, 0.01, 0.05, 0.1')
plt.xlabel('steps ( 25 steps * 240 = 6000 steps )')
plt.ylabel('average rewards')
plt.show()


# In[96]:


### plot
## pcl, tau
plt.figure(figsize=(12, 8))
plt.plot(pcl_avg_reward_tau_dot01, label='tau = 0.01')
plt.plot(pcl_avg_reward_tau_dot05, label='tau = 0.05')
plt.plot(pcl_avg_reward_tau_dot1, label='tau = 0.1')
plt.plot(pcl_avg_reward_tau_dot5, label='tau = 0.5')
plt.legend(loc='upper left', prop={'size': LEGEND_SIZE})
plt.grid(True)
plt.title('pcl reward, tau = 0.01, 0.05, 0.1, 0.5')
plt.xlabel('steps ( 25 steps * 240 = 6000 steps )')
plt.ylabel('average rewards')
plt.show()


# In[97]:


### plot
## pcl, critic weight
plt.figure(figsize=(12, 8))
plt.plot(pcl_avg_reward_critic_weight_dot1, label='critic weight = 0.1')
plt.plot(pcl_avg_reward_critic_weight_dot5, label='critic weight = 0.5')
plt.plot(pcl_avg_reward_critic_weight_dot10, label='critic weight = 1.0')
plt.legend(loc='upper left', prop={'size': LEGEND_SIZE})
plt.grid(True)
plt.title('pcl reward, critic weight = 0.1, 0.5, 1.0')
plt.xlabel('steps ( 25 steps * 240 = 6000 steps )')
plt.ylabel('average rewards')
plt.show()


# In[98]:


### plot
## a3c, learning rate
plt.figure(figsize=(12, 8))
plt.plot(a3c_avg_reward_lr_dot005, label='lr = 0.005')
plt.plot(a3c_avg_reward_lr_dot01, label='lr = 0.01')
plt.plot(a3c_avg_reward_lr_dot05, label='lr = 0.05')
plt.plot(a3c_avg_reward_lr_dot1, label='lr = 0.1')
plt.legend(loc='upper left', prop={'size': LEGEND_SIZE})
plt.grid(True)
plt.title('a3c reward, learning rate = 0.005, 0.01, 0.05, 0.1')
plt.xlabel('steps ( 25 steps * 240 = 6000 steps )')
plt.ylabel('average rewards')
plt.show()


# In[99]:


### plot
## pcl, tau
plt.figure(figsize=(12, 8))
plt.plot(a3c_avg_reward_tau_dot01, label='tau = 0.01')
plt.plot(a3c_avg_reward_tau_dot05, label='tau = 0.05')
plt.plot(a3c_avg_reward_tau_dot1, label='tau = 0.1')
plt.plot(a3c_avg_reward_tau_dot5, label='tau = 0.5')
plt.legend(loc='upper left', prop={'size': LEGEND_SIZE})
plt.grid(True)
plt.title('a3c reward, tau = 0.01, 0.05, 0.1, 0.5')
plt.xlabel('steps ( 25 steps * 240 = 6000 steps )')
plt.ylabel('average rewards')
plt.show()


# In[109]:


### plot
## a3c, critic weight
plt.figure(figsize=(12, 8))
plt.plot(a3c_avg_reward_critic_weight_dot1, label='critic weight = 0.1')
plt.plot(a3c_avg_reward_critic_weight_dot5, label='critic weight = 0.5')
plt.plot(a3c_avg_reward_critic_weight_dot10, label='critic weight = 1.0')
plt.legend(loc='upper left', prop={'size': LEGEND_SIZE})
plt.grid(True)
plt.title('a3c reward, critic weight = 0.1, 0.5, 1.0')
plt.xlabel('steps ( 25 steps * 240 = 6000 steps )')
plt.ylabel('average rewards')
plt.show()


# In[101]:


### plot
## a3c, critic weight
plt.figure(figsize=(12, 8))
plt.plot(pcl_avg_reward_best3, label='pcl')
plt.plot(a3c_avg_reward_best3, label='a3c')
plt.legend(loc='upper left', prop={'size': LEGEND_SIZE})
plt.grid(True)
plt.title('pcl, a3c best 3')
plt.xlabel('steps ( 25 steps * 240 = 6000 steps )')
plt.ylabel('average rewards')
plt.show()


# In[155]:


### plot
## a3c, critic weight
plt.figure(figsize=(12, 8))
plt.plot(pcl_avg_reward_best3_1, label='pcl')
plt.plot(a3c_avg_reward_best3_1, label='a3c')
plt.legend(loc='upper left', prop={'size': LEGEND_SIZE})
plt.grid(True)
plt.title('pcl, a3c best 3 (lr = 0.005)')
plt.xlabel('steps ( 25 steps * 400 = 10000 steps )')
plt.ylabel('average rewards')
plt.show()


# In[ ]:




