# PCL
---------------------------
Available algorithms:
 - PCL
 - Actor-Critic

Requirements:
 - TensorFlow 1.x only, not support Tensorflow 2
 - OpenAI Gym
 - Numpy
 - Scipy

Usage & instruction:
> python trainer.py --logtostderr --batch_size=400 --env=DuplicatedInput-v0 \
  --validation_frequency=25 --tau=0.025 --rollout=10 --critic_weight=0.1 \
  --gamma=0.9 --clip_norm=10 --replay_buffer_freq=1 --objective=pcl  \         --learning_rate=0.01 --num_steps=10000


Result:
 - Run PCL method with learning rate = 0.005, 0.01, 0.05, 0.1 and show the result.
![](https://i.imgur.com/PG8Drqj.png)

 - Run PCL method with tau = 0.01, 0.05, 0.1, 0.5 
![](https://i.imgur.com/zyRlHUO.png)

 - Run PCL method with critic weight = 0.1, 0.5, 1.0
![](https://i.imgur.com/MO4x6Q8.png)

 - Run A3C method with learning rate = 0.005, 0.01, 0.05, 0.1
![](https://i.imgur.com/2c9dNla.png)

 - Run A3C with tau = 0.01, 0.05, 0.1, 0.5
![](https://i.imgur.com/DxpvBMT.png)

 - Run A3C with critic weight = 0.1, 0.5, 1.0
![](https://i.imgur.com/XxEOJny.png)

 - plot the six experiment in one image
![](https://i.imgur.com/sqMg4Sf.png)


 - Run PCL and A3C with the 3 best parameter we found.
![](https://i.imgur.com/fFZt0Ke.png)

 - Because PCL reward always be -1, so we change the learning rate from 0.1 to 0.005
![](https://i.imgur.com/hOIe5Ag.png)

Reference
 - Bridging the Gap Between Value and Policy BasedReinforcement Learning
    https://arxiv.org/pdf/1702.08892.pdf








