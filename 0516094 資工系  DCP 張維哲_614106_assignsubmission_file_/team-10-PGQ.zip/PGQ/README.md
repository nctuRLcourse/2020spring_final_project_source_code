# PGQ

## Dependency
- `tensorflow 1.13.1`
- See `requirements.txt` for more details

## References
[Combining policy gradient and Q-learning
](https://arxiv.org/abs/1611.01626)


## Usage
`python pgq.py`