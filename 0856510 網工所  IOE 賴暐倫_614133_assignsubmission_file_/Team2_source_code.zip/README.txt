Sample Efficient Actor-Critic With Experience Replay

Package requirement

Pytorch > 1.4
Numpy > 1.19


Reference
We modified our code from the repository of the following one.
[RL-Adventure-2: Policy Gradients](https://github.com/higgsfield/RL-Adventure-2)

