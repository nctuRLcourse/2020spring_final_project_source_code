# Distributional Reward Decomposition for Reinforcement Learning

This is an attempt at implementing the code from the paper Distributional Reward Decomposition for Reinforcement Learning (2019)

The algorithm is based on Rainbow and tries to split the reward signal in sub reward distributions without any external information.

This code is not fully working at the moment.

# Usage

To train the agent, just run the notebook on google colab

# References
* Lin, Zichuan & Zhao, Li & Yang, Derek & Qin, Tao & Yang, Guangwen & Liu, Tie-Yan. (2019). Distributional Reward Decomposition for Reinforcement Learning. 