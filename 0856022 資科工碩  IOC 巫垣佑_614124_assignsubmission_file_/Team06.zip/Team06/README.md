# TD3 Ablation
Implementation of TD3 ablation, advanced more Q experiment and add PBT in TD3. Our code is based on the author's ([TD3](https://github.com/sfujim/TD3)).
We use Roboschool as out experiment envionment. See the link below for installation and usage.
# Dependency
* Pytorch v1.4.0
* [Roboschool v1.0.48](https://github.com/openai/roboschool)
* ray v0.8.6

# Usage
## TD3 Ablation
```
python3 main.py --policy TD3 --env <env> --ablation <ablation> --seed <seed>
```

## More Q Experiments
```
python3 main_Q.py --policy <algo> --env <env> --seed <seed>
```

## PBT
```
python TD3-pbt.py --env <env>
```

# Curves
## Reproduction
![](https://i.imgur.com/jjsR1S4.png)

## TD3 Ablation
* Apply only 1 trick
![](https://i.imgur.com/N2sQqA1.png)

* Remove 1 trick
![](https://i.imgur.com/pgKEqVH.png)

* Ablation Result
![](https://i.imgur.com/NBRQvWI.png)

## More Q Experiment
![](https://i.imgur.com/paObLxV.png)

## PBT
![](https://i.imgur.com/oIrj93D.png)


# References
* [Addressing Function Approximation Error in Actor-Critic Methods](https://arxiv.org/abs/1802.09477)
* [TD3](https://github.com/sfujim/TD3)
* [Population Based Training of Neural Networks](https://arxiv.org/abs/1711.09846)