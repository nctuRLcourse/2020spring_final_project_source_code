
import os
os.environ['CUDA_VISIBLE_DEVICES'] = '0,1,2,3,4,5,6,7'

import gym
import roboschool
from itertools import count
from collections import namedtuple
import numpy as np

import utils
import copy
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.distributions import Categorical
import torch.optim.lr_scheduler as Scheduler
from torch.nn.functional import smooth_l1_loss
import itertools
import argparse

import ray
from ray.tune import Trainable, run
from ray.tune.schedulers import PopulationBasedTraining

ray.init(num_gpus=8)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

parser = argparse.ArgumentParser()
parser.add_argument("--env", default="RoboschoolWalker2d-v1")		  # OpenAI gym environment name
parser.add_argument("--start_timesteps", default=25e3, type=int)# Time steps initial random policy is used
parser.add_argument("--max_timesteps", default=5e4, type=int)   # Max time steps to run environment
parser.add_argument("--expl_noise", default=0.1)				# Std of Gaussian exploration noise
parser.add_argument("--batch_size", default=256, type=int)	  # Batch size for both actor and critic
parser.add_argument("--postfix", default='v1', type=str)
args = parser.parse_args()

env_ = gym.make(args.env)

class Actor(nn.Module):
	def __init__(self, state_dim, action_dim, max_action):
		super(Actor, self).__init__()

		self.l1 = nn.Linear(state_dim, 256)
		self.l2 = nn.Linear(256, 256)
		self.l3 = nn.Linear(256, action_dim)
		
		self.max_action = max_action
		

	def forward(self, state):
		a = F.relu(self.l1(state))
		a = F.relu(self.l2(a))
		return self.max_action * torch.tanh(self.l3(a))


class Critic(nn.Module):
	def __init__(self, state_dim, action_dim):
		super(Critic, self).__init__()

		# Q1 architecture
		self.l1 = nn.Linear(state_dim + action_dim, 256)
		self.l2 = nn.Linear(256, 256)
		self.l3 = nn.Linear(256, 1)

		# Q2 architecture
		self.l4 = nn.Linear(state_dim + action_dim, 256)
		self.l5 = nn.Linear(256, 256)
		self.l6 = nn.Linear(256, 1)


	def forward(self, state, action):
		sa = torch.cat([state, action], 1)

		q1 = F.relu(self.l1(sa))
		q1 = F.relu(self.l2(q1))
		q1 = self.l3(q1)

		q2 = F.relu(self.l4(sa))
		q2 = F.relu(self.l5(q2))
		q2 = self.l6(q2)
		return q1, q2

	def Q1(self, state, action):
		sa = torch.cat([state, action], 1)

		q1 = F.relu(self.l1(sa))
		q1 = F.relu(self.l2(q1))
		q1 = self.l3(q1)
		return q1


def select_action(actor, state):
	state = torch.FloatTensor(state.reshape(1, -1)).to(device)
	return actor(state).cpu().data.numpy().flatten()

def eval_policy(actor, eval_episodes=10):
	eval_env = copy.deepcopy(env_)

	avg_reward = 0.0
	for _ in range(eval_episodes):
		state, done = eval_env.reset(), False
		while not done:
			action = select_action(actor, np.array(state))
			state, reward, done, _ = eval_env.step(action)
			avg_reward += reward
	return avg_reward / eval_episodes

def train(env, critic, actor, critic_optimizer, actor_optimizer, config, args):
	discount = float(config['discount'])
	tau = float(config['tau'])
	policy_noise = float(config['policy_noise'])
	noise_clip = float(config['noise_clip'])
	policy_freq = int(config['policy_freq'])

	policy_freq = int(np.clip(policy_freq, 1, 10))
	discount = np.clip(discount, 0.9, 1)
	tau = np.clip(tau, 0.00001, 0.1)
	policy_noise = np.clip(policy_noise, 0, 1)
	noise_clip = np.clip(noise_clip, 0, 1)

	critic_target = copy.deepcopy(critic)
	actor_target = copy.deepcopy(actor)
	
	state_dim = env.observation_space.shape[0]
	action_dim = env.action_space.shape[0] 
	max_action = float(env.action_space.high[0])

	kwargs = {
		"state_dim": state_dim,
		"action_dim": action_dim,
		"max_action": max_action,
		"discount": discount,
		"tau": tau,
		"policy_noise": policy_noise * max_action,
		"noise_clip": noise_clip * max_action,
		"policy_freq": policy_freq
	}

	replay_buffer = utils.ReplayBuffer(state_dim, action_dim)

	state_, done = env.reset(), False
	episode_reward = 0
	episode_timesteps = 0
	episode_num = 0
	total_it = 0
	test_score_reward = 0

	for t in range(int(args.max_timesteps)):
		
		episode_timesteps += 1

		# Select action randomly or according to policy
		if t < args.start_timesteps:
			action = env.action_space.sample()
		else:
			action = (
				select_action(actor, np.array(state_))
				+ np.random.normal(0, max_action * args.expl_noise, size=action_dim)
			).clip(-max_action, max_action)

		# Perform action
		next_state, reward, done, _ = env.step(action) 
		done_bool = float(done) if episode_timesteps < env._max_episode_steps else 0

		# Store data in replay buffer
		replay_buffer.add(state_, action, next_state, reward, done_bool)

		state_ = next_state
		episode_reward += reward

		# Train agent after collecting sufficient data
		if t >= args.start_timesteps:
			total_it += 1
			# Sample replay buffer 
			state, action, next_state, reward, not_done = replay_buffer.sample(args.batch_size)
			with torch.no_grad():
				# Select action according to policy and add clipped noise
				noise = (
					torch.randn_like(action) * kwargs['policy_noise']
				).clamp(-kwargs['noise_clip'], kwargs['noise_clip'])

				next_action = (
					actor_target(next_state) + noise
				).clamp(-kwargs['max_action'], kwargs['max_action'])
				# Compute the target Q value
				target_Q1, target_Q2 = critic_target(next_state, next_action)
				target_Q = torch.min(target_Q1, target_Q2)
				target_Q = reward + not_done * kwargs['discount'] * target_Q
			# Get current Q estimates
			current_Q1, current_Q2 = critic(state, action)
			# Compute critic loss
			critic_loss = F.mse_loss(current_Q1, target_Q) + F.mse_loss(current_Q2, target_Q)
			# Optimize the critic
			critic_optimizer.zero_grad()
			critic_loss.backward()
			critic_optimizer.step()
			# Delayed policy updates
			if total_it % kwargs['policy_freq'] == 0:
				# Compute actor losse
				actor_loss = -critic.Q1(state, actor(state)).mean()

				# Optimize the actor 
				actor_optimizer.zero_grad()
				actor_loss.backward()
				actor_optimizer.step()
				# Update the frozen target models
				for param, target_param in zip(critic.parameters(), critic_target.parameters()):
					target_param.data.copy_(kwargs['tau'] * param.data + (1 - kwargs['tau']) * target_param.data)
				for param, target_param in zip(actor.parameters(), actor_target.parameters()):
					target_param.data.copy_(kwargs['tau'] * param.data + (1 - kwargs['tau']) * target_param.data)

		if done: 
			# Reset environment
			state_, done = env.reset(), False
			test_score_reward = 0.05 * episode_reward + (1 - 0.05) * test_score_reward
			episode_reward = 0
			episode_timesteps = 0
			episode_num += 1
	
	test_reward = eval_policy(actor)		

	#return test_score_reward
	return test_reward

class TD3(Trainable):
	def _setup(self, config):
		self.env = copy.deepcopy(env_)
		state_dim = self.env.observation_space.shape[0]
		action_dim = self.env.action_space.shape[0] 
		max_action = float(self.env.action_space.high[0])
		self.critic = Critic(state_dim, action_dim).to(device)
		self.critic_optimizer = torch.optim.Adam(self.critic.parameters(), lr=config.get("lr", 3e-4))
		self.actor = Actor(state_dim, action_dim, max_action).to(device)
		self.actor_optimizer = torch.optim.Adam(self.actor.parameters(), lr=config.get("lr", 3e-4))
		
	def _train(self):
		test_score = -10000
		try:
			test_score = train(self.env, self.critic, self.actor, self.critic_optimizer, self.actor_optimizer, self.config, args)
		except:
			pass
		return {"test_score": test_score}

	def _save(self, checkpoint_dir):
		checkpoint_path = os.path.join(checkpoint_dir, "model.pth")
		torch.save({
			'critic': self.critic.state_dict(),
			'critic_optimizer': self.critic_optimizer.state_dict(),
			'actor': self.actor.state_dict(),
			'actor_optimizer': self.actor_optimizer.state_dict()
		} , checkpoint_path)
		return checkpoint_path

	def _restore(self, checkpoint_path):
		ckpt = torch.load(checkpoint_path)
		self.critic.load_state_dict(ckpt["critic"])
		self.critic_optimizer.load_state_dict(ckpt["critic_optimizer"])
		self.actor.load_state_dict(ckpt["actor"])
		self.actor_optimizer.load_state_dict(ckpt["actor_optimizer"])

	def reset_config(self, new_config):
		for param_group in self.critic_optimizer.param_groups:
			if "lr" in new_config:
				param_group["lr"] = new_config["lr"]
		for param_group in self.actor_optimizer.param_groups:
			if "lr" in new_config:
				param_group["lr"] = new_config["lr"]

		self.config = new_config
		self.env.reset()
		return True

if __name__ == '__main__':
	scheduler = PopulationBasedTraining(
		time_attr="training_iteration",
		metric="test_score",
		mode="max",
		perturbation_interval=2,
		hyperparam_mutations={
			"lr": lambda: np.random.uniform(0.00001, 0.01),
			"discount": lambda: np.random.uniform(0.9, 1),
			"tau": lambda: np.random.uniform(0.00001, 0.1),
			"policy_noise": lambda: np.random.uniform(0, 1),
			"noise_clip": lambda: np.random.uniform(0, 1),
			"policy_freq": lambda: np.random.uniform(0, 10),
		})
	
	analysis = ray.tune.run(
		TD3,
		resources_per_trial={'gpu': 0.5},
		name=f"TD3_{args.env}_{args.postfix}",
		scheduler=scheduler,
		reuse_actors=True,
		verbose=1,
		checkpoint_score_attr="test_score",
		checkpoint_freq=2,
		keep_checkpoints_num=1,
		num_samples=16,
		config={
			"lr": ray.tune.uniform(0.00001, 0.01),
			"discount": ray.tune.uniform(0.9, 1),
			"tau": ray.tune.uniform(0.00001, 0.1),
			"policy_noise": ray.tune.uniform(0, 1),
			"noise_clip": ray.tune.uniform(0, 1),
			"policy_freq": ray.tune.uniform(1, 10),
		})