def get_g_h_act():
  lst = [1,2]
  return lst
