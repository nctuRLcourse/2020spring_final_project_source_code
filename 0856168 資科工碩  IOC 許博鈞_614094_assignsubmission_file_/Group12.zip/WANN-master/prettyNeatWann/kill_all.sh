kill -9 `ps aux | grep wann_train | tr -s ' ' | cut -d" " -f2`

