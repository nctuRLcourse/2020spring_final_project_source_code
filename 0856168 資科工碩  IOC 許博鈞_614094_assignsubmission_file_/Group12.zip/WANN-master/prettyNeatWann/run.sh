#!/bin/bash

./biped_all.sh
./biped.sh
./biped_r.sh
