rm -rf log/*
rm -rf *.png *.csv *.txt
