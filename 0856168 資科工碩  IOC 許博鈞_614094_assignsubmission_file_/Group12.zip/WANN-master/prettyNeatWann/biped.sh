#!/bin/bash

./train.sh biped [1,2] 2
./train.sh biped [1,3] 3 
./train.sh biped [1,4] 4 
./train.sh biped [1,5] 5 
./train.sh biped [1,6] 6 
./train.sh biped [1,7] 7 
./train.sh biped [1,8] 8 
./train.sh biped [1,9] 9 
./train.sh biped [1,10] 10
./train.sh biped [1,11] 11
