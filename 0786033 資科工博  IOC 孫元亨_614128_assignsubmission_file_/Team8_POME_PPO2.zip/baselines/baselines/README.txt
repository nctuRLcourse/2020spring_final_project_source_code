﻿
Readme
-------------

This is an replicated implementation of "Policy Optimization with Model-based Explorations" (POME) reinforcement learning method of the paper: https://arxiv.org/abs/1811.07350. 


> **Note:**

> - POME is a modified version of the well-known Proximal Policy Optimization algorithm (PPO) so our implementation will be based on OpenAI Baseline which is  "a set of high-quality implementations of reinforcement learning algorithms" including PPO
> - OpenAI Baseline information and source code: 
> https://github.com/openai/baselines

The POME algorimth involves two additional parts compares to PPO: 
1. Fitting the model 
2. Adding the discrepancy (exploration) of targets.


#### </i> Fitting the model 

We use a neural network to fit state transition. The inputs of the transition network have two parts, the state and the action. Before being fed into the model, the state are scaled to the range[0,1], and the action is one-hot encoded. We concatenate the one-hot encoding of the action to the state to form the inputs of the transition model. 
This is implemented in the file:
baselines\baselines\common\policies.py. 
The original OpenAI Baseline code without incorporating model-based is kept in the file:
 baselines\baselines\common\policies_ORI.py. 


#### </i> Adding the discrepancy (exploration) of targets.

To implement line 5-15 of the POME algorithm stated in the paper we have modified OpenAI Baseline ppo2 code as in the file: 
baselines\baselines\ppo2\runner.py.
The original PPO OpenAI Baseline implementation is kept in the file:
 baselines\baselines\common\policies_ORI.py. 

#### </i> Running POME and PPO

With our implementation: 
 - To run POME, please use:  python -m baselines.run --alg=ppo2 --env=AmidarNoFrameskip-v0 --num_timesteps=2e7 --save_path=~/models/AmidarNoFrameskip-v0 --log_path=~/logs/AmidarNoFrameskip-v0/

- To run PPO, please use: python -m baselines.run --alg=ppo2 --env=AmidarNoFrameskip-v0 --num_timesteps=2e7 --save_path=~/models/AmidarNoFrameskip-v0 --log_path=~/logs/AmidarNoFrameskip-v0/

( You need to rename baselines\baselines\ppo2\rurnner_ORI.py to baselines\baselines\ppo2\rurnner.py and baselines\baselines\common\policies_ORI.py to baselines\baselines\common\policies.py )

You can find the the result "~/logs/AmidarNoFrameskip-v0/"


